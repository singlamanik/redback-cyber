import React from "react";
const Context = React.createContext(false);

export default Context;
